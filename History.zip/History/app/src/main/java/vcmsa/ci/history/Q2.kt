package vcmsa.ci.history

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Q2 : AppCompatActivity() {


    val questions = arrayOf(
        " The Rosetta Stone was crucial in deciphering hieroglyphic writing.",
        "Marie Curie was the first woman to win a Nobel Prize. ",
        "The Silk Road connected Europe and China.",
        "The Great Wall of China is the longest wall in the world.",
        "The Renaissance was a period of artistic and intellectual revival in Europe."
    )

    val answers = arrayOf(true,false,true,false,true)

    var index = 0
    var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q2)


        val questionText = findViewById<TextView>(R.id.questionText)
        val feedbackText = findViewById<TextView>(R.id.feedback)
        val trueButton = findViewById<TextView>(R.id.trueButton)
        val falseButton = findViewById<Button>(R.id.falseButton)
        val nextButton = findViewById<Button>(R.id.nextButton)

        fun showQuestion() {
            questionText.text = questions[index]
            feedbackText.text= ""
            trueButton.isEnabled= true
            falseButton.isEnabled= true
            nextButton.isEnabled= false
        }
        @SuppressLint("SetTextI18n")
        fun checkAnswer (userAnswer: Boolean) {
            val correct = answers [index]
            if (userAnswer == correct) {
                feedbackText.text = "Correct!"
                score++
            } else {
                feedbackText.text= "Incorrect!"
            }
            trueButton.isEnabled = false
            falseButton.isEnabled = false
            nextButton.isEnabled = true
        }
        fun goToNext () {
            index ++
            if (index < questions.size) {
                showQuestion()
            } else {
                val intent = Intent(this,Q3::class.java)
                intent.putExtra("score", score)
                startActivity(intent)
                finish()
            }
        }
        trueButton.setOnClickListener{ checkAnswer(true)}
        falseButton.setOnClickListener{checkAnswer(false)}
        nextButton.setOnClickListener{goToNext()}






        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}