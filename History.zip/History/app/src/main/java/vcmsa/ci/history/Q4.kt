package vcmsa.ci.history

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class Q4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_q4)

        class ReviewActivity : AppCompatActivity() {

            private val questions = arrayOf(
                " The Rosetta Stone was crucial in deciphering hieroglyphic writing.",
                "Marie Curie was the first woman to win a Nobel Prize. ",
                "The Silk Road connected Europe and China.",
                "The Great Wall of China is the longest wall in the world.",
                "The Renaissance was a period of artistic and intellectual revival in Europe."
            )

            private val answers = arrayOf(true, false, true, false, true)

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_q4)

                val reviewText = findViewById<TextView>(R.id.reviewText)
                val builder = StringBuilder()
                for (i in questions.indices) {
                    builder.append("${i + 1}. ${questions[i]} - Answer: ${if (answers[i]) "True" else "False"}\n\n")
                }
                reviewText.text = builder.toString()
            }
        }
    }
}



